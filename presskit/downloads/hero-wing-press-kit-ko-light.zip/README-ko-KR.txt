Hero Wing(히로윙) 경향게임스 기사제보용 경량 프레스 키트

게임명: 히로윙 (Hero Wing)
개발/유통: 종이배게임즈 (Paper Boat Games)
플랫폼: Android (Google Play)
출시: 2026년 7월

Google Play
https://play.google.com/store/apps/details?id=com.paperboatgames.herowing2026

공식 트레일러
https://youtu.be/4i2Qahw9Whk

포함 파일
- screenshot_0000.jpg ~ screenshot_0004.jpg: 한국어 스토어 스크린샷 5장
- hero-wing-logo.png: 게임 로고
- paper-boat-games-logo.png: 종이배게임즈 로고

이 파일들은 기사제보 폼의 2MB 제한에 맞춘 경량본입니다.
고해상도 PNG와 고화질 플레이 영상이 필요하면 paperboathelp@gmail.com으로 요청해 주세요.
